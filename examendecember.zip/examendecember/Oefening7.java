package examendecember;
import java.util.Scanner;

public class Oefening7 {
	Scanner s = new Scanner(System.in);
	 public static void main(String[] args) {
		 Oefening7 oef= new Oefening7();
		 oef.oef7();
}
	 public void oef7() {
			System.out.println("|Voer een zin in|");
			String zin = s.nextLine();
			System.out.println("|Voer een optie in(1, 2, 3,)|");
			int optie = s.nextInt();
			
			switch (optie) {
			case 1:
				optie1(zin);
			break;
			case 2:
				optie2(zin);
			break;
			case 3:
				optie3(zin);
			break;
			}
	 }
	 public void optie1(String zin) {
		 String zin2 = zin.replaceAll("[b,c,d,f,g,h,j,k,l,m,n,p,q,r,s,t,v,w,x,z]","");
		 int letters = 0;
	      for (int i = 0; i < zin2.length(); i++) {
	          if (Character.isLetter(zin2.charAt(i)))
	             letters++;
	       }
	       System.out.println(letters);
	    }
	 public void optie2(String zin) {
		 String zin2 = zin.replaceAll("[a,e,i,o,u", "");
		 int letters = 0;
	      for (int i = 0; i < zin2.length(); i++) {
	          if (Character.isLetter(zin2.charAt(i)))
	             letters++;
	       }
	       System.out.println(letters);
	    }
	 public void optie3(String zin){
		 int letters = 0;
	      for (int i = 0; i < zin.length(); i++) {
	          if (Character.isLetter(zin.charAt(i)))
	             letters++;
	       }
	       System.out.println(letters);
	    } 
	 }

