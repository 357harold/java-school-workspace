package examendecember;

public class Oefening1 {

	 public static void main(String[] args) {
		 Oefening1 oef= new Oefening1();
		 oef.oef1();
		 
	 }
	 public void oef1() {
			for (int i = -50; i > -91; i--) {
				if (i != -54)
				if (i != -60)
				if (i != -66)
				if (i != -72)
				if (i != -78)
				if (i != -84)
				if (i != -90)
					resultaadoef1(i);
			}
		}
	 public void resultaadoef1(int i) {
		 System.out.println(i);
	 }
}
