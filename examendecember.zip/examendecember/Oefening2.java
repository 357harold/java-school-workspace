package examendecember;

public class Oefening2 {
	 public static void main(String[] args) {
		 Oefening2 oef= new Oefening2();
		 oef.oef2();
}
	 public void oef2() {
			int[][][] a = new int[20][10][];

			for (int i = 0; i < a.length; i++) {
				int i = i + 1;
				for (int j = 0; j < a[i].length; j++) {
					int j = j + 1;
					int k = Math.random(); {
						a[i][j][k]= i+j;
				resultaadoef2(a[i][j][k]);
				}
				System.out.println();
			}

		}
	 }
	 public void resultaadoef2(int a) {
		 System.out.println(a[i][j][k]);
	 }
}


