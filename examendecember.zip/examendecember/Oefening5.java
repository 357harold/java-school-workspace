package examendecember;

public class Oefening5 {
	 public static void main(String[] args) {
		 Oefening5 oef= new Oefening5();
		 oef.oef5();
}
	 public void oef5() {
		 for (int i = 0; i < 1000; i++) {
		int a = 3*i;
		int b = 5*i;
		int c = a+b;
		if(c<1000) {
		resultaadoef5(c);
}
}
}
	 public void resultaadoef5(int c) {
		 System.out.println(c);
		 
	 }
}