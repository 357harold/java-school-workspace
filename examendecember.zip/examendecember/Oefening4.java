package examendecember;

public class Oefening4 {
	public static void main(String[] args) {
		Oefening4 oef = new Oefening4();
		oef.oef4();
	}

	public void oef4() {
		int a = 0;
		while ((a == 0) || (a < 80)) {
			a=a+1;
			resultaadoef4(a);
		}
}
	public void resultaadoef4 (int a) {
		System.out.println(a);
	}
}
