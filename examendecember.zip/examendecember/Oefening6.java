package examendecember;
import java.util.Scanner;
public class Oefening6 {
	Scanner s = new Scanner(System.in);
	 public static void main(String[] args) {
		 Oefening6 oef= new Oefening6();
		 oef.oef6();
}
	 public void oef6() {
			System.out.println("Geef een zin");	
			String zin = s.nextLine();
			System.out.println("Geef een woord in dat vervangen moet worden:");
			String woord = s.nextLine();
			if(woord.contains(a)) {
			draaimethod(zin, woord);		
		}
	 }
		private String draaimethod(String zin, String woord) {
			String vervanging = "";
			for (int i = woord.length()-1; i >=0; i--) {
				vervanging = vervanging + woord.charAt(i);
			}
			String zin2 =zin.replaceAll(woord,vervanging);
			resultaadoef6(zin2);
			
		}
		private void resultaadoef6(String zin2) {
			System.out.println(zin2);
		}
		}

