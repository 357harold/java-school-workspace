create table artist (
id integer primary key auto_increment ,
title varchar(255) not null
);

create table albums(
id integer primary key auto_increment,
albumtitle varchar(255) not null,
artist integer,
constraint FK_artist FOREIGN KEY (artist) REFERENCES artist(id)
);
drop table albums ;
create table Track(
id integer primary key auto_increment,
name varchar(255) not null,
album integer,
constraint FK_album FOREIGN KEY (album) REFERENCES albums(id)
);
drop table tracks ;