package sql;

public class Track {
	public String name;
	public int albumid;
	
	public Track(String name, int albumid) {
		this.name = name;
		this.albumid = albumid;
	}
}


