package sql;

public class Album {
	
	public String title;
	public int artistid;
	
	public Album(String title, int artistid) {
		this.title = title;
		this.artistid = artistid;
	}

}
